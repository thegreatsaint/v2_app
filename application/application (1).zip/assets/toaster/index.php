<?php
include("../../include/dbconfig.php");
header("location:".site_address);
?>