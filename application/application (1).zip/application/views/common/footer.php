<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<h1 class="label2">&nbsp;</h1>

  <footer class="footer_bar_section" style="width:100%; position:fixed; font-size:0.7em; bottom:0px; left:0px">
  		<!--
  		<div class="btn btn-block btn-default text-left btn-sm">
        	<span class="credits font-weight-light"><b>Developed by</b> <img src="<?php echo $this->config->item("base_url");?>assets/images/site_images/gst.png" width="20px"/>&nbsp;The GST</span>
        </div>
        -->
  </footer>
</div><!--main div-->

</body>
</html>